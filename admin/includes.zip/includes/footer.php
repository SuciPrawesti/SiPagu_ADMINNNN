<?php
/**
 * FOOTER TEMPLATE - SiPagu
 * Lokasi: admin/includes/footer.php
 * HANYA footer content saja
 */
?>
<!-- Footer -->
<footer class="main-footer">
    <div class="footer-left">
        Copyright &copy; <?= date('Y') ?>
        <div class="bullet"></div>
        SiPagu - Sistem Pengelolaan Keuangan Suci & Azkiya
    </div>
</footer>